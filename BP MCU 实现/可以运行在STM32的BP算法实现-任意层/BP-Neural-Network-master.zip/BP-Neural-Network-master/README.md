# BP-Neural-Network
this is BP Neural Network written by C language , it's useful , I have used it in MCUs ,such as STM32F407ZGT6 , MSP430F5529 , and so on
(Please forgive my poor English。。)
  the detail description is following：
·The Function Of This Program
   This is a BP Neural Network , the main functions are function fitting , data prediction and data classification.

·The description of files
1 BPNetwork.c and BPNetwork.h
They are the main files which contain the training of BP Neural Network,the setting up of network,and so on.

2 BPSim.c and BPSim.h
They are used for simulation of network

3 test.c and test.h
they contain some test functions 

4 rand.c and rand.h
they provide the rand number

5 data.txt
this file is the output file,which contains the paraments of the network

6 test.txt
this file is the simulation result,containing the result of simulation
