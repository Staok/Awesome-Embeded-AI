#ifndef RAND_H
#define RAND_H
unsigned int random(void);

#endif