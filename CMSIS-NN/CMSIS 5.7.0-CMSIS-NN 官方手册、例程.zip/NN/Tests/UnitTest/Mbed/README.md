Current Mbed version is 5.15.5:

https://github.com/ARMmbed/mbed-os/releases/tag/mbed-os-5.15.5

This is corresponding commit url:

https://github.com/ARMmbed/mbed-os/commit/6a244d7adffc0e93872cfc880e539ee11bbc6002

To change Mbed version change the commit url in mbed-os.lib.
