README
======

This test suite is deprecated. Don't use it.
It will be removed from the CMSIS-DSP folder in the future.
