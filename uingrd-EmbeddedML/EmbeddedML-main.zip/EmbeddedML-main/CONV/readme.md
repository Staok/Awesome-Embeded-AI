# 快速卷积和近似卷积
- 文件说明
 1. approxi_conv_1D.py 近似1D卷积
 2. approxi_conv_2D.py 近似2D卷积
 3. DFT_CONV.py 基于DFT的卷积运算
 4. FAST_CONV_1D.py 快速1D卷积
 5. FAST_CONV_2D.py 快速2D卷积
 6. FAST_FIR.py 快速1D FIR运算
 7. fast_fir.c 实现FAST_FIR.py内的算法以及测试程序，该代码使用脚本build.py编译运行
 8. fast_conv_1d.c 实现FAST_CONV_1D.py内的算法以及测试程序，该代码使用脚本build.py编译运行
