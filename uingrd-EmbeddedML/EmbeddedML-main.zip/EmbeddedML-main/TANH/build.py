import os
os.system('gcc -o ./tanh_approx tanh_approx.c -std=c99')
os.system('tanh_approx')