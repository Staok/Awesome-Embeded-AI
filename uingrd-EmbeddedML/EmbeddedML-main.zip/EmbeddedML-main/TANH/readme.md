# tanh的几种近似计算方法
1. 分别用python和C实现
2. C程序使用命令：
gcc -o ./tanh_approx tanh_approx.c -std=c99 
编译，编译结果是tanh_approx(*.exe)，运行它得到几种不同的近似tanh计算方法误差
(在build.py可也可以完成编译和测试)