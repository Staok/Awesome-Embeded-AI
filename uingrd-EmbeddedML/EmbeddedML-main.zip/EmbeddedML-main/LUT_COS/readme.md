# 基于查表实现的快速COS算法演示
- lut_cos.py
基于python的查表实现cos计算的演示和误差测量

- lut_cos.c
基于C的查表实现cos计算的演示和误差测量，编译命令是：gcc -o lut_cos lut_cos.c -std=c99，生成可执行文件是lut_cos(.exe)
