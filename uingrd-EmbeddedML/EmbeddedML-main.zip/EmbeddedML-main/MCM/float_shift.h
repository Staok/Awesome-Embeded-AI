#ifndef __FLOAT_SHIFT__
#define __FLOAT_SHIFT__

float float_shift(float x, int s);
double double_shift(double x, int s);

#endif
