 # 矩阵乘法的快速运算
1. arrpox_mat_mul.py
基于数据低秩近似的快速矩阵算法
2. circulant_mat_mul.py    
验证通过DFT计算循环矩阵和向量乘积
3. strassen_mul_np.py      
Strassem快速矩阵乘法
4. svd_mat_mul.py          
基于矩阵低秩近似的快速矩阵算法(使用SVD实现矩阵近似近似)
5. vq_mat_mul.py           
基于向量量化的近似矩阵乘法
6. winograd_mat_mul.py     
Winograd快速矩阵乘法
